#ifndef __REGISTRAARQUIVO_H_
#define __REGISTRAARQUIVO_H_

void registra_vitoria(char *nome, int tentativas, int acertos_jogador);
void imprime_registro();

#endif