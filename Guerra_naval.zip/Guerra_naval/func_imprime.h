#ifndef __FUNCIMPRIME_H_
#define __FUNCIMPRIME_H_

void mostra_tabuleiro(int **tabuleiro);
void mostraTabuleiroDificil(int **tabuleiro);
void imprime_menu();
void imprime_vencedor();
void imprime_perdedor();
void imprime_legenda();

#endif